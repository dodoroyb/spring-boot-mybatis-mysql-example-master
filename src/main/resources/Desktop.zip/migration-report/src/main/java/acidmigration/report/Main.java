package acidmigration.report;

import java.io.FileOutputStream;
import java.io.IOException;
/**
 * https://zenn.dev/takaki/articles/java-xml-dom
 */
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.w3c.dom.Document;

public class Main {
	
	private final static String DIR_PRJ_HOME = System.getProperty("user.dir");
	
	public static void main(final String[] args) throws Exception {
		final Path path = Paths.get(DIR_PRJ_HOME + "\\test.html");
		final DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
		final DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
		final Document document = documentBuilder.parse(path.toFile());

		final XPath xpath = XPathFactory.newInstance().newXPath();

		final String h1 = (String) xpath.evaluate("/html/body/div/h1/text()", document, XPathConstants.STRING);

		p(h1);

		final String h1c = (String) xpath.evaluate("/html/body/div/h1/@class", document, XPathConstants.STRING);
		p(h1c);

		final String div = (String) xpath.evaluate("//div[2]/text()", document, XPathConstants.STRING);

		p(div);
		final String li = (String) xpath.evaluate("//div[2]/ul[1]/li[1]/text()", document, XPathConstants.STRING);
		p(li);
		final String li3 = (String) xpath.evaluate("//div[2]/ul[1]/li[2]/text()", document, XPathConstants.STRING);
		p(li3);
		
		
		System.out.println(DIR_PRJ_HOME);
		write2excel();
		
	}
	
	private static void write2excel() throws EncryptedDocumentException, InvalidFormatException, IOException {
		Workbook outputWorkbook = new XSSFWorkbook();
		Sheet sheet = outputWorkbook.createSheet();
		Row outputRow = sheet.createRow(1);
		Cell  outputCell = outputRow.createCell(1);
	
		outputCell.setCellValue("値値値");
		FileOutputStream out = new FileOutputStream(DIR_PRJ_HOME + "\test.xlsx");

		
		outputWorkbook.write(out);
		
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	private static void p(Object o) {
		System.out.println(o.toString());
	}
}